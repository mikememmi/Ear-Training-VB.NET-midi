﻿Option Explicit On

Public Class frmEar1
    Dim strNotes(50) As String
    Dim intPreviousNote As Integer = -1

    Dim strWriteFolder As String = IO.Directory.GetParent(Application.ExecutablePath).FullName
    Dim strFileSettings As String = strWriteFolder & "\initials.txt"
    Dim strSavedSettings As String = ""
    Dim bolUpdating As Boolean = False
    Dim strFileMidiA As String = strWriteFolder & "\mmmidA.MID"
    Dim strFileMidiB As String = strWriteFolder & "\mmmidB.MID"

    Dim strLastUpdateSettings(12) As String

    Dim strAllScalesData() As String =
        {"37,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,0", 'Chromatic
        "22,0,2,4,5,7,9,10,12,14,16,17,19,21,22,24,26,28,29,31,33,34,36,0", 'Major
        "22,0,1,4,5,7,8,10,12,13,16,17,19,20,22,24,25,28,29,31,32,34,36,0", 'Harmonic Minor
        "22,0,1,3,5,7,8,10,12,13,15,17,19,20,22,24,25,27,29,31,32,34,36,0", 'Melodic Minor Descending
        "22,0,2,4,5,7,8,10,12,14,16,17,19,20,22,24,26,28,29,31,32,34,36,0", 'Melodic Minor Ascending
        "16,0,3,5,8,10,12,15,17,20,22,24,27,29,32,34,36,0", 'Pentatonic
        "19,0,3,5,8,10,11,12,15,17,20,22,23,24,27,29,32,34,35,36,0"} 'Pentatonic Plus(Sharp "4")

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim x1 As Integer = 0
        Dim bolNewSetOfNotes As Boolean = False
        Dim bolNewTempo As Boolean = False
        bolUpdating = True
        wmp1.Ctlcontrols.stop()
        wmp1.URL = ""
        If strLastUpdateSettings(6) <> cmbScale.SelectedIndex Or strLastUpdateSettings(7) <> cmbKey.SelectedIndex Then
            bolNewSetOfNotes = True
        End If
        If strLastUpdateSettings(9) <> numudTempo.Value Then
            bolNewTempo = True
        End If
        Do While cmbRangeH.SelectedIndex - cmbRangeL.SelectedIndex < 5
            If cmbRangeL.SelectedIndex <> 0 Then
                cmbRangeL.SelectedIndex = cmbRangeL.SelectedIndex - 1
            End If
            If cmbRangeH.SelectedIndex <> 36 Then
                cmbRangeH.SelectedIndex = cmbRangeH.SelectedIndex + 1
            End If
        Loop
        strLastUpdateSettings(0) = cmbReps.SelectedIndex
        strLastUpdateSettings(1) = cmbNotes.SelectedIndex
        strLastUpdateSettings(2) = cmbTime.SelectedIndex
        strLastUpdateSettings(3) = cmbPause.SelectedIndex
        strLastUpdateSettings(4) = cmbRangeL.SelectedIndex
        strLastUpdateSettings(5) = cmbRangeH.SelectedIndex
        strLastUpdateSettings(6) = cmbScale.SelectedIndex
        strLastUpdateSettings(7) = cmbKey.SelectedIndex
        strLastUpdateSettings(8) = cmbInstrument.SelectedIndex
        strLastUpdateSettings(9) = numudTempo.Value
        wmp1.settings.playCount = strLastUpdateSettings(0) + 1
        If bolNewSetOfNotes = True Then
            ScaleAndKey()
        End If
        If bolNewTempo = True Then
            Tempo_Bytes()
        End If

        Filewrite(strFileMidiA)

        Filewrite(strFileMidiB)


        bolUpdating = False

        strSavedSettings = ""
        For x1 = 0 To 11
            strSavedSettings = strSavedSettings + Str(strLastUpdateSettings(x1)) + ","
        Next

        If My.Computer.FileSystem.FileExists(strFileSettings) Then
            My.Computer.FileSystem.DeleteFile(strFileSettings)
        End If

        My.Computer.FileSystem.WriteAllText(strFileSettings, strSavedSettings, False)
        btnPause.Text = "Pause"


    End Sub

    Private Sub frmEar1_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim x2 As Integer

        Randomize()
        frmEar1_Resize(sender, e)
        If Not My.Computer.FileSystem.FileExists(strFileSettings) Then
            cmbReps.SelectedIndex = 0
            cmbNotes.SelectedIndex = 3
            cmbTime.SelectedIndex = 0
            cmbPause.SelectedIndex = 0
            cmbRangeL.SelectedIndex = 0
            cmbRangeH.SelectedIndex = 36
            cmbScale.SelectedIndex = 0
            cmbKey.SelectedIndex = 0
            cmbInstrument.SelectedIndex = 0
            numudTempo.Value = 60
            strLastUpdateSettings(0) = cmbReps.SelectedIndex
            strLastUpdateSettings(1) = cmbNotes.SelectedIndex
            strLastUpdateSettings(2) = cmbTime.SelectedIndex
            strLastUpdateSettings(3) = cmbPause.SelectedIndex
            strLastUpdateSettings(4) = cmbRangeL.SelectedIndex
            strLastUpdateSettings(5) = cmbRangeH.SelectedIndex
            strLastUpdateSettings(6) = cmbScale.SelectedIndex
            strLastUpdateSettings(7) = cmbKey.SelectedIndex
            strLastUpdateSettings(8) = cmbInstrument.SelectedIndex
            strLastUpdateSettings(9) = numudTempo.Value
            strLastUpdateSettings(10) = 2
            strLastUpdateSettings(11) = 0

            strSavedSettings = ""
            For x2 = 0 To 11
                strSavedSettings = strSavedSettings + Str(strLastUpdateSettings(x2)) + ","
            Next

            My.Computer.FileSystem.WriteAllText(strFileSettings, strSavedSettings, True)
        Else
            strSavedSettings = My.Computer.FileSystem.ReadAllText(strFileSettings)

            strLastUpdateSettings = Strings.Split(strSavedSettings, (","))

            cmbReps.SelectedIndex = strLastUpdateSettings(0)
            cmbNotes.SelectedIndex = strLastUpdateSettings(1)
            cmbTime.SelectedIndex = strLastUpdateSettings(2)
            cmbPause.SelectedIndex = strLastUpdateSettings(3)
            cmbRangeL.SelectedIndex = strLastUpdateSettings(4)
            cmbRangeH.SelectedIndex = strLastUpdateSettings(5)
            cmbScale.SelectedIndex = strLastUpdateSettings(6)
            cmbKey.SelectedIndex = strLastUpdateSettings(7)
            cmbInstrument.SelectedIndex = strLastUpdateSettings(8)
            numudTempo.Value = strLastUpdateSettings(9)


        End If
        ScaleAndKey()
        Filewrite(strFileMidiA)
        Filewrite(strFileMidiB)
        wmp1.URL = strFileMidiB
        wmp1.settings.playCount = strLastUpdateSettings(0) + 1
        wmp1.Ctlcontrols.stop()
    End Sub



    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If Not bolUpdating Then
            If wmp1.status = "Stopped" Or wmp1.status = "Ready" Then
                If wmp1.URL = strFileMidiA Then
                    wmp1.URL = ""
                    wmp1.URL = strFileMidiB
                Else
                    wmp1.URL = ""
                    wmp1.URL = strFileMidiA
                End If
                wmp1.Ctlcontrols.play()
                If wmp1.URL = strFileMidiA Then
                    Filewrite(strFileMidiB)
                Else
                    Filewrite(strFileMidiA)
                End If
            End If
        End If
    End Sub

    Private Sub Filewrite(strFilePath As String)
        Dim bytMidiHeader() As Byte = {&H4D, &H54, &H68, &H64, &H0, &H0, &H0, &H6}
        Dim bytSubFormatType() As Byte = {&H0, &H0} ' Type-1 MIDI file (as opposed to Type-0)
        Dim bytTrackNumber() As Byte = {&H0, &H1}
        Dim bytSpeed() As Byte = {CByte(strLastUpdateSettings(10)), CByte(strLastUpdateSettings(11))}  ' Tempo (sort of)
        Dim bytTrackHeader() As Byte = {&H4D, &H54, &H72, &H6B, &H0, &H0, &H0}
        Dim bytTempByteCount As Byte
        bytTempByteCount = CByte(((strLastUpdateSettings(1) + 1) * 7) + 12 + (strLastUpdateSettings(3) * 7))
        Dim bytTrackByteCount() As Byte = {bytTempByteCount} 'number of notes + 4 for silence and 4 for bytTrackEnd + 3 for instrument change + 1 for first &H0 of data section
        Dim bytTrackNoteData(500) As Byte
        Dim bytHoldEachNote() As Byte = {&HFF}
        Dim bytTrackPauseData() As Byte = {&H0, &H3E, &H0, &H83, &H0, &H3E, &H0}
        Dim bytTrackSilenceAll() As Byte = {&H7F, &HB0, &H7B, &H0}
        Dim bytTrackEnd() As Byte = {&H0, &HFF, &H2F, &H0}
        Dim bytInstrument() As Byte = {&H0, &HC0, CByte(strLastUpdateSettings(8))}
        Dim x3 As Integer
        Dim intNoteCount As Integer
        Dim intRestCount As Integer = strLastUpdateSettings(3)
        Dim intNoteTiming As Integer



        intNoteCount = (strLastUpdateSettings(1) + 1)
        x3 = 0
        bytTrackNoteData(0) = &H0
        intPreviousNote = -1
        Do Until x3 = intNoteCount
            If ((x3 * 7) + 1) = 1 Then
                bytTrackNoteData((x3 * 7) + 1) = &H90
            Else
                bytTrackNoteData((x3 * 7) + 1) = &H0
            End If
            bytTrackNoteData((x3 * 7) + 2) = GetNote()
            bytTrackNoteData((x3 * 7) + 3) = &H60

            If strLastUpdateSettings(2) = 4 Then
                intNoteTiming = CSng(Int(Rnd() * 4))
            Else
                intNoteTiming = strLastUpdateSettings(2)
            End If
            Select Case (intNoteTiming)
                Case 0
                    bytTrackNoteData((x3 * 7) + 4) = &H81
                Case 1
                    bytTrackNoteData((x3 * 7) + 4) = &H82
                Case 2
                    bytTrackNoteData((x3 * 7) + 4) = &H84
                Case 3
                    bytTrackNoteData((x3 * 7) + 4) = &H88
            End Select

            bytTrackNoteData((x3 * 7) + 5) = &H0
            bytTrackNoteData((x3 * 7) + 6) = bytTrackNoteData((x3 * 7) + 2)
            bytTrackNoteData((x3 * 7) + 7) = &H0
            x3 = x3 + 1
        Loop

        If My.Computer.FileSystem.FileExists(strFilePath) Then
            My.Computer.FileSystem.DeleteFile(strFilePath)
        End If
        My.Computer.FileSystem.WriteAllBytes(strFilePath, bytMidiHeader, True)
        My.Computer.FileSystem.WriteAllBytes(strFilePath, bytSubFormatType, True)
        My.Computer.FileSystem.WriteAllBytes(strFilePath, bytTrackNumber, True)
        My.Computer.FileSystem.WriteAllBytes(strFilePath, bytSpeed, True)
        My.Computer.FileSystem.WriteAllBytes(strFilePath, bytTrackHeader, True)
        My.Computer.FileSystem.WriteAllBytes(strFilePath, bytTrackByteCount, True)
        My.Computer.FileSystem.WriteAllBytes(strFilePath, bytInstrument, True)
        For x3 = 0 To (intNoteCount * 7)
            bytHoldEachNote(0) = bytTrackNoteData(x3)
            My.Computer.FileSystem.WriteAllBytes(strFilePath, bytHoldEachNote, True)
        Next
        For x3 = 1 To intRestCount
            My.Computer.FileSystem.WriteAllBytes(strFilePath, bytTrackPauseData, True)
        Next
        My.Computer.FileSystem.WriteAllBytes(strFilePath, bytTrackSilenceAll, True)
        My.Computer.FileSystem.WriteAllBytes(strFilePath, bytTrackEnd, True)

    End Sub

    Private Sub ScaleAndKey()
        Dim x4 As Integer = 0
        Dim strSelectedScale As String
        Dim x6 As Integer
        x6 = strLastUpdateSettings(6)    '6 corresponds to cmbScale
        strSelectedScale = strAllScalesData(x6)
        Array.Clear(strNotes, 0, strNotes(0))
        strNotes = Split(strSelectedScale, ",")
        For x4 = 1 To strNotes(0)
            strNotes(x4) = Int(strNotes(x4)) + Int(strLastUpdateSettings(7))  '7 corresponds to cmbKey
            If strNotes(x4) > 36 Then
                strNotes(x4) = Int(strNotes(x4)) - 36
            End If
            If strNotes(x4) = 36 And strLastUpdateSettings(7) <> 0 Then
                strNotes(0) = Int(strNotes(0)) + 1
            End If
        Next
    End Sub

    Private Function GetNote() As Byte

        Dim bytNextNote As Byte
        Dim x5 As Integer = 0
        Dim intNewNote As Integer
        Dim bolNotePasses As Boolean = False
        Do While bolNotePasses = False
            intNewNote = CSng(Int(Rnd() * 37))
            For x5 = 1 To Int(strNotes(0))
                If intNewNote = strNotes(x5) Then
                    bolNotePasses = True
                End If
            Next
            If bolNotePasses = True And intPreviousNote <> -1 Then
                If intNewNote = intPreviousNote Then
                    bolNotePasses = False
                End If
            End If
            If bolNotePasses = True And intPreviousNote <> -1 Then
                If (intPreviousNote < (intNewNote - 12) Or intPreviousNote > (intNewNote + 12)) Then
                    bolNotePasses = False
                End If
            End If
            If bolNotePasses = True And (intNewNote < strLastUpdateSettings(4) Or intNewNote > strLastUpdateSettings(5)) Then
                bolNotePasses = False
            End If
        Loop
        intPreviousNote = intNewNote
        bytNextNote = CByte(intNewNote + 40)
        Return bytNextNote

    End Function

    Private Sub btnPause_Click(sender As Object, e As EventArgs) Handles btnPause.Click
        If btnPause.Text = "Play" Then
            wmp1.Ctlcontrols.play()
            btnPause.Text = "Pause"
        Else
            wmp1.Ctlcontrols.pause()
            btnPause.Text = "Play"
        End If
    End Sub

    Private Sub frmEar1_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Dim Ctrl As System.Windows.Forms.Control
        For Each Ctrl In Me.Controls
            If TypeOf Ctrl Is ComboBox Or TypeOf Ctrl Is NumericUpDown Then
                Ctrl.Left = Me.Width / 2
                Ctrl.Top = 60 + (Ctrl.TabIndex * 35)
            End If
            If TypeOf Ctrl Is Label Then
                Ctrl.Width = 140
                Ctrl.Left = (Me.Width / 2) - 155
                Ctrl.Top = 60 + (Ctrl.TabIndex * 35)
            End If
            If TypeOf Ctrl Is Button Then
                Ctrl.Width = 135
                Ctrl.Left = (Me.Width / 2) - 150
            End If

        Next
    End Sub

    Private Sub Tempo_Bytes()
        Dim intBeatsPerSec As Integer
        Dim lngMidiTicks As Long
        intBeatsPerSec = numudTempo.Value
        lngMidiTicks = intBeatsPerSec * 8.533333
        strLastUpdateSettings(10) = (Int(lngMidiTicks / 256))
        strLastUpdateSettings(11) = (Int(lngMidiTicks) Mod 256)
        txtMisc.Text = strLastUpdateSettings(10)
        txtWmpStatus.Text = strLastUpdateSettings(11)

    End Sub

End Class