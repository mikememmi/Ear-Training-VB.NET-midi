﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEar1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEar1))
        Me.cmbNotes = New System.Windows.Forms.ComboBox()
        Me.btnPause = New System.Windows.Forms.Button()
        Me.wmp1 = New AxWMPLib.AxWindowsMediaPlayer()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.txtWmpStatus = New System.Windows.Forms.TextBox()
        Me.txtMisc = New System.Windows.Forms.TextBox()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.cmbReps = New System.Windows.Forms.ComboBox()
        Me.cmbTime = New System.Windows.Forms.ComboBox()
        Me.cmbPause = New System.Windows.Forms.ComboBox()
        Me.cmbRangeL = New System.Windows.Forms.ComboBox()
        Me.cmbRangeH = New System.Windows.Forms.ComboBox()
        Me.cmbScale = New System.Windows.Forms.ComboBox()
        Me.cmbKey = New System.Windows.Forms.ComboBox()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl7 = New System.Windows.Forms.Label()
        Me.lbl8 = New System.Windows.Forms.Label()
        Me.lbl9 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.Dir1 = New System.DirectoryServices.DirectoryEntry()
        Me.cmbInstrument = New System.Windows.Forms.ComboBox()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.numudTempo = New System.Windows.Forms.NumericUpDown()
        Me.lbl10 = New System.Windows.Forms.Label()
        CType(Me.wmp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numudTempo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmbNotes
        '
        Me.cmbNotes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbNotes.FormattingEnabled = True
        Me.cmbNotes.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32"})
        Me.cmbNotes.Location = New System.Drawing.Point(272, 155)
        Me.cmbNotes.Name = "cmbNotes"
        Me.cmbNotes.Size = New System.Drawing.Size(121, 21)
        Me.cmbNotes.TabIndex = 3
        '
        'btnPause
        '
        Me.btnPause.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPause.Location = New System.Drawing.Point(45, 12)
        Me.btnPause.Name = "btnPause"
        Me.btnPause.Size = New System.Drawing.Size(136, 61)
        Me.btnPause.TabIndex = 1
        Me.btnPause.Text = "Pause"
        Me.btnPause.UseVisualStyleBackColor = True
        '
        'wmp1
        '
        Me.wmp1.Enabled = True
        Me.wmp1.Location = New System.Drawing.Point(202, 450)
        Me.wmp1.Name = "wmp1"
        Me.wmp1.OcxState = CType(resources.GetObject("wmp1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.wmp1.Size = New System.Drawing.Size(169, 46)
        Me.wmp1.TabIndex = 2
        Me.wmp1.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'txtWmpStatus
        '
        Me.txtWmpStatus.Location = New System.Drawing.Point(240, 38)
        Me.txtWmpStatus.Name = "txtWmpStatus"
        Me.txtWmpStatus.Size = New System.Drawing.Size(116, 20)
        Me.txtWmpStatus.TabIndex = 3
        Me.txtWmpStatus.Visible = False
        '
        'txtMisc
        '
        Me.txtMisc.Location = New System.Drawing.Point(240, 12)
        Me.txtMisc.Name = "txtMisc"
        Me.txtMisc.Size = New System.Drawing.Size(116, 20)
        Me.txtMisc.TabIndex = 4
        Me.txtMisc.Visible = False
        '
        'btnUpdate
        '
        Me.btnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.Location = New System.Drawing.Point(45, 454)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(136, 40)
        Me.btnUpdate.TabIndex = 5
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'cmbReps
        '
        Me.cmbReps.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbReps.FormattingEnabled = True
        Me.cmbReps.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbReps.Location = New System.Drawing.Point(257, 116)
        Me.cmbReps.Name = "cmbReps"
        Me.cmbReps.Size = New System.Drawing.Size(121, 21)
        Me.cmbReps.TabIndex = 2
        '
        'cmbTime
        '
        Me.cmbTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTime.FormattingEnabled = True
        Me.cmbTime.Items.AddRange(New Object() {"Sixteenth", "Eighth", "Quarter", "Half", "Random"})
        Me.cmbTime.Location = New System.Drawing.Point(282, 193)
        Me.cmbTime.Name = "cmbTime"
        Me.cmbTime.Size = New System.Drawing.Size(121, 21)
        Me.cmbTime.TabIndex = 4
        '
        'cmbPause
        '
        Me.cmbPause.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPause.FormattingEnabled = True
        Me.cmbPause.Items.AddRange(New Object() {"0 Quarter Notes", "1 Quarter Note", "2 Quarter Notes", "3 Quarter Notes", "4 Quarter Notes", "5 Quarter Notes", "6 Quarter Notes", "7 Quarter Notes", "8 Quarter Notes", "9 Quarter Notes", "10 Quarter Notes", "11 Quarter Notes", "12 Quarter Notes", "13 Quarter Notes", "14 Quarter Notes", "15 Quarter Notes", "16 Quarter Notes"})
        Me.cmbPause.Location = New System.Drawing.Point(282, 227)
        Me.cmbPause.Name = "cmbPause"
        Me.cmbPause.Size = New System.Drawing.Size(121, 21)
        Me.cmbPause.TabIndex = 5
        '
        'cmbRangeL
        '
        Me.cmbRangeL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbRangeL.FormattingEnabled = True
        Me.cmbRangeL.Items.AddRange(New Object() {"0  - E 3", "1  - F 3", "2  - F# 3", "3  - G 3", "4  - G# 3", "5  - A 4", "6  - A# 4", "7  - B 4", "8  - C 4", "9  - C# 4", "10 - D 4", "11 - D# 4", "12 - E 4", "13 - F 4", "14 - F# 4", "15 - G 4", "16 - G# 4", "17 - A 5", "18 - A# 5", "19 - B 5", "20 - C 5", "21 - C# 5", "22 - D 5", "23 - D# 5", "24 - E 5", "25 - F 5", "26 - F# 5", "27 - G 5", "28 - G# 5", "29 - A 6", "30 - A# 6", "31 - B 6", "32 - C 6", "33 - C# 6", "34 - D 6", "35 - D# 6", "36 - E 6"})
        Me.cmbRangeL.Location = New System.Drawing.Point(288, 266)
        Me.cmbRangeL.Name = "cmbRangeL"
        Me.cmbRangeL.Size = New System.Drawing.Size(121, 21)
        Me.cmbRangeL.TabIndex = 6
        '
        'cmbRangeH
        '
        Me.cmbRangeH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbRangeH.FormattingEnabled = True
        Me.cmbRangeH.Items.AddRange(New Object() {"0  - E3", "1  - F 3", "2  - F# 3", "3  - G 3", "4  - G# 3", "5  - A 4", "6  - A# 4", "7  - B 4", "8  - C 4", "9  - C# 4", "10 - D 4", "11 - D# 4", "12 - E 4", "13 - F 4", "14 - F# 4", "15 - G 4", "16 - G# 4", "17 - A 5", "18 - A# 5", "19 - B 5", "20 - C 5", "21 - C# 5", "22 - D 5", "23 - D# 5", "24 - E 5", "25 - F 5", "26 - F# 5", "27 - G 5", "28 - G# 5", "29 - A 6", "30 - A# 6", "31 - B 6", "32 - C 6", "33 - C# 6", "34 - D 6", "35 - D# 6", "36 - E 6"})
        Me.cmbRangeH.Location = New System.Drawing.Point(288, 303)
        Me.cmbRangeH.Name = "cmbRangeH"
        Me.cmbRangeH.Size = New System.Drawing.Size(121, 21)
        Me.cmbRangeH.TabIndex = 7
        '
        'cmbScale
        '
        Me.cmbScale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbScale.FormattingEnabled = True
        Me.cmbScale.Items.AddRange(New Object() {"Chromatic", "Major", "Harmonic Minor", "Melodic Minor Descending", "Melodic Minor Ascending", "Pentatonic", "Pentatonic Plus (Sharp ""4"")"})
        Me.cmbScale.Location = New System.Drawing.Point(282, 348)
        Me.cmbScale.Name = "cmbScale"
        Me.cmbScale.Size = New System.Drawing.Size(160, 21)
        Me.cmbScale.TabIndex = 8
        '
        'cmbKey
        '
        Me.cmbKey.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbKey.FormattingEnabled = True
        Me.cmbKey.Items.AddRange(New Object() {"A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G"})
        Me.cmbKey.Location = New System.Drawing.Point(235, 387)
        Me.cmbKey.Name = "cmbKey"
        Me.cmbKey.Size = New System.Drawing.Size(121, 21)
        Me.cmbKey.TabIndex = 9
        '
        'lbl2
        '
        Me.lbl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2.Location = New System.Drawing.Point(78, 114)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(103, 21)
        Me.lbl2.TabIndex = 2
        Me.lbl2.Text = "Repetitions"
        Me.lbl2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbl5
        '
        Me.lbl5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5.Location = New System.Drawing.Point(61, 227)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(120, 21)
        Me.lbl5.TabIndex = 5
        Me.lbl5.Text = "Pause At End"
        Me.lbl5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbl6
        '
        Me.lbl6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6.Location = New System.Drawing.Point(78, 266)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(103, 21)
        Me.lbl6.TabIndex = 6
        Me.lbl6.Text = "Low Range"
        Me.lbl6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbl4
        '
        Me.lbl4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4.Location = New System.Drawing.Point(78, 193)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(103, 21)
        Me.lbl4.TabIndex = 4
        Me.lbl4.Text = "Timing"
        Me.lbl4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbl7
        '
        Me.lbl7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7.Location = New System.Drawing.Point(78, 303)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(103, 21)
        Me.lbl7.TabIndex = 7
        Me.lbl7.Text = "High Range"
        Me.lbl7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbl8
        '
        Me.lbl8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8.Location = New System.Drawing.Point(78, 348)
        Me.lbl8.Name = "lbl8"
        Me.lbl8.Size = New System.Drawing.Size(103, 21)
        Me.lbl8.TabIndex = 8
        Me.lbl8.Text = "Scale"
        Me.lbl8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbl9
        '
        Me.lbl9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl9.Location = New System.Drawing.Point(78, 387)
        Me.lbl9.Name = "lbl9"
        Me.lbl9.Size = New System.Drawing.Size(103, 21)
        Me.lbl9.TabIndex = 9
        Me.lbl9.Text = "Key"
        Me.lbl9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbl3
        '
        Me.lbl3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3.Location = New System.Drawing.Point(41, 153)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(140, 21)
        Me.lbl3.TabIndex = 3
        Me.lbl3.Text = "Number of Notes"
        Me.lbl3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cmbInstrument
        '
        Me.cmbInstrument.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbInstrument.FormattingEnabled = True
        Me.cmbInstrument.Items.AddRange(New Object() {"Acoustic Grand Piano", "Bright Acoustic Piano", "Electric Grand Piano", "Honky Tonk Piano", "Electric Piano 1", "Electric Piano 2", "Harpsichord", "Clavinet", "Celesta", "Glockenspiel", "Music Box", "Vibraphone", "Marimba", "Xylophone", "Tubular Bells", "Dulcimer", "Drawbar Organ", "Percussive Organ", "Rock Organ", "Church Organ", "Reed Organ", "Accordian", "Harmonica", "Tango Accordian", "Acoustic Guitar (Nylon)", "Acoustic Guitar (Steel)", "Electric Guitar (Jazz)", "Electric Guitar (Clean)", "Electric Guitar (Muted)", "Overdriven Guitar", "Distortion Guitar", "Guitar Harmonics", "Acoustic Bass", "Electric Bass (Finger)", "Electric Bass (Pick)", "Fretless Bass", "Slap Bass 1", "Slap Bass 2", "Synth Bass 1", "Synth Bass 2", "Violin", "Viola", "Cello", "Contrabass", "Tremelo Strings", "Pizzicato Strings", "Orchestral Harp", "Timpani", "String Ensemble 1", "String Ensemble 2", "Synth Strings 1", "Synth Strings 2", "Choir Aahs", "Voice Oohs", "Synth Choir", "Orchestral Hit", "Trumpet", "Trombone", "Tuba", "Muted Trumpet", "French Horn", "Brass Section", "Synth Brass 1", "Synth Brass 2", "Soprano Sax", "Alto Sax", "Tenor Sax", "Baritone Sax", "Oboe", "English Horn", "Bassoon", "Clarinet", "Piccolo", "Flute", "Recorder", "Pan Flute", "Blown Bottle", "Shakuhachi", "Whistle", "Ocarina"})
        Me.cmbInstrument.Location = New System.Drawing.Point(301, 89)
        Me.cmbInstrument.Name = "cmbInstrument"
        Me.cmbInstrument.Size = New System.Drawing.Size(133, 21)
        Me.cmbInstrument.TabIndex = 1
        '
        'lbl1
        '
        Me.lbl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(78, 89)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(103, 21)
        Me.lbl1.TabIndex = 1
        Me.lbl1.Text = "Instrument"
        Me.lbl1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'numudTempo
        '
        Me.numudTempo.Location = New System.Drawing.Point(322, 429)
        Me.numudTempo.Maximum = New Decimal(New Integer() {210, 0, 0, 0})
        Me.numudTempo.Minimum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.numudTempo.Name = "numudTempo"
        Me.numudTempo.Size = New System.Drawing.Size(120, 20)
        Me.numudTempo.TabIndex = 10
        Me.numudTempo.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'lbl10
        '
        Me.lbl10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10.Location = New System.Drawing.Point(198, 429)
        Me.lbl10.Name = "lbl10"
        Me.lbl10.Size = New System.Drawing.Size(103, 21)
        Me.lbl10.TabIndex = 10
        Me.lbl10.Text = "Tempo BPM"
        Me.lbl10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'frmEar1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(484, 512)
        Me.Controls.Add(Me.lbl10)
        Me.Controls.Add(Me.numudTempo)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.cmbInstrument)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.lbl9)
        Me.Controls.Add(Me.lbl8)
        Me.Controls.Add(Me.lbl7)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl6)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.cmbKey)
        Me.Controls.Add(Me.cmbScale)
        Me.Controls.Add(Me.cmbRangeH)
        Me.Controls.Add(Me.cmbRangeL)
        Me.Controls.Add(Me.cmbPause)
        Me.Controls.Add(Me.cmbTime)
        Me.Controls.Add(Me.cmbReps)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.txtMisc)
        Me.Controls.Add(Me.txtWmpStatus)
        Me.Controls.Add(Me.wmp1)
        Me.Controls.Add(Me.btnPause)
        Me.Controls.Add(Me.cmbNotes)
        Me.Name = "frmEar1"
        Me.Text = "All Ears"
        CType(Me.wmp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numudTempo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmbNotes As ComboBox
    Friend WithEvents btnPause As Button
    Friend WithEvents wmp1 As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents Timer1 As Timer
    Friend WithEvents txtWmpStatus As TextBox
    Friend WithEvents txtMisc As TextBox
    Friend WithEvents btnUpdate As Button
    Friend WithEvents cmbReps As ComboBox
    Friend WithEvents cmbTime As ComboBox
    Friend WithEvents cmbPause As ComboBox
    Friend WithEvents cmbRangeL As ComboBox
    Friend WithEvents cmbRangeH As ComboBox
    Friend WithEvents cmbScale As ComboBox
    Friend WithEvents cmbKey As ComboBox
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl5 As Label
    Friend WithEvents lbl6 As Label
    Friend WithEvents lbl4 As Label
    Friend WithEvents lbl7 As Label
    Friend WithEvents lbl8 As Label
    Friend WithEvents lbl9 As Label
    Friend WithEvents lbl3 As Label
    Friend WithEvents Dir1 As DirectoryServices.DirectoryEntry
    Friend WithEvents cmbInstrument As ComboBox
    Friend WithEvents lbl1 As Label
    Friend WithEvents numudTempo As NumericUpDown
    Friend WithEvents lbl10 As Label
End Class
