﻿Option Explicit On

Public Class frmEar1
    Dim Notes_Scale_And_Key(50) As String
    Dim Previous_Note As Integer = -1
    Dim Write_Folder As String = IO.Directory.GetParent(Application.ExecutablePath).FullName


    Dim filepath2 As String = Write_Folder & "\initials.txt"
    Dim Saved_Settings As String = ""                 ' btnUpdate_Click & frmEar1_Load
    Dim Updating_Bool = False                        ' btn_Update_Click & Timer1_Click
    Dim filepathA As String = Write_Folder & "\mmmidA.MID"
    Dim filepathB As String = Write_Folder & "\mmmidB.MID"

    Dim Last_Update_Combo_Values(12) As String  'btnUpdate_Click & frmEar1_Load & Timer1_Tick

    Dim All_Scales_Data() As String =
        {"37,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,0",
        "22,0,2,4,5,7,9,10,12,14,16,17,19,21,22,24,26,28,29,31,33,34,36,0",
        "22,0,1,4,5,7,8,10,12,13,16,17,19,20,22,24,25,28,29,31,32,34,36,0",
        "22,0,1,3,5,7,8,10,12,13,15,17,19,20,22,24,25,27,29,31,32,34,36,0",
        "22,0,2,4,5,7,8,10,12,14,16,17,19,20,22,24,26,28,29,31,32,34,36,0",
        "16,0,3,5,8,10,12,15,17,20,22,24,27,29,32,34,36,0",
        "19,0,3,5,8,10,11,12,15,17,20,22,23,24,27,29,32,34,35,36,0"}

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim x1 As Integer = 0
        Dim New_Note_Set_Bool As Boolean = False
        Dim New_Tempo_Bool As Boolean = False
        Updating_Bool = True
        wmp1.Ctlcontrols.stop()
        wmp1.URL = ""
        If Last_Update_Combo_Values(6) <> cmbScale.SelectedIndex Or Last_Update_Combo_Values(7) <> cmbKey.SelectedIndex Then
            New_Note_Set_Bool = True
        End If
        If Last_Update_Combo_Values(9) <> numudTempo.Value Then
            New_Tempo_Bool = True
        End If
        Do While cmbRangeH.SelectedIndex - cmbRangeL.SelectedIndex < 5
            If cmbRangeL.SelectedIndex <> 0 Then
                cmbRangeL.SelectedIndex = cmbRangeL.SelectedIndex - 1
            End If
            If cmbRangeH.SelectedIndex <> 36 Then
                cmbRangeH.SelectedIndex = cmbRangeH.SelectedIndex + 1
            End If
        Loop
        Last_Update_Combo_Values(0) = cmbReps.SelectedIndex
        Last_Update_Combo_Values(1) = cmbNotes.SelectedIndex
        Last_Update_Combo_Values(2) = cmbTime.SelectedIndex
        Last_Update_Combo_Values(3) = cmbPause.SelectedIndex
        Last_Update_Combo_Values(4) = cmbRangeL.SelectedIndex
        Last_Update_Combo_Values(5) = cmbRangeH.SelectedIndex
        Last_Update_Combo_Values(6) = cmbScale.SelectedIndex
        Last_Update_Combo_Values(7) = cmbKey.SelectedIndex
        Last_Update_Combo_Values(8) = cmbInstrument.SelectedIndex
        Last_Update_Combo_Values(9) = numudTempo.Value
        wmp1.settings.playCount = Last_Update_Combo_Values(0) + 1
        If New_Note_Set_Bool = True Then
            ScaleAndKey()
        End If
        If New_Tempo_Bool = True Then
            Tempo_Bytes()
        End If

        Filewrite(filepathA)

        Filewrite(filepathB)


        wmp1.URL = "C:\Users\DELL\Desktop\mmmidA.MID"
        Updating_Bool = False

        Saved_Settings = ""
        For x1 = 0 To 11
            Saved_Settings = Saved_Settings + Str(Last_Update_Combo_Values(x1)) + ","
        Next

        If My.Computer.FileSystem.FileExists(filepath2) Then
            My.Computer.FileSystem.DeleteFile(filepath2)
        End If

        My.Computer.FileSystem.WriteAllText(filepath2, Saved_Settings, False)
        btnPause.Text = "Pause"


    End Sub

    Private Sub frmEar1_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim x2 As Integer

        Randomize()
        frmEar1_Resize(sender, e)
        If Not My.Computer.FileSystem.FileExists(filepath2) Then
            cmbReps.SelectedIndex = 0
            cmbNotes.SelectedIndex = 3
            cmbTime.SelectedIndex = 0
            cmbPause.SelectedIndex = 0
            cmbRangeL.SelectedIndex = 0
            cmbRangeH.SelectedIndex = 36
            cmbScale.SelectedIndex = 0
            cmbKey.SelectedIndex = 0
            cmbInstrument.SelectedIndex = 0
            numudTempo.value = 60
            Last_Update_Combo_Values(0) = cmbReps.SelectedIndex
            Last_Update_Combo_Values(1) = cmbNotes.SelectedIndex
            Last_Update_Combo_Values(2) = cmbTime.SelectedIndex
            Last_Update_Combo_Values(3) = cmbPause.SelectedIndex
            Last_Update_Combo_Values(4) = cmbRangeL.SelectedIndex
            Last_Update_Combo_Values(5) = cmbRangeH.SelectedIndex
            Last_Update_Combo_Values(6) = cmbScale.SelectedIndex
            Last_Update_Combo_Values(7) = cmbKey.SelectedIndex
            Last_Update_Combo_Values(8) = cmbInstrument.SelectedIndex
            Last_Update_Combo_Values(9) = numudTempo.Value
            Last_Update_Combo_Values(10) = 2
            Last_Update_Combo_Values(11) = 0

            Saved_Settings = ""
            For x2 = 0 To 11
                Saved_Settings = Saved_Settings + Str(Last_Update_Combo_Values(x2)) + ","
            Next

            My.Computer.FileSystem.WriteAllText(filepath2, Saved_Settings, True)
        Else
            Saved_Settings = My.Computer.FileSystem.ReadAllText(filepath2)

            Last_Update_Combo_Values = Strings.Split(Saved_Settings, (","))

            cmbReps.SelectedIndex = Last_Update_Combo_Values(0)
            cmbNotes.SelectedIndex = Last_Update_Combo_Values(1)
            cmbTime.SelectedIndex = Last_Update_Combo_Values(2)
            cmbPause.SelectedIndex = Last_Update_Combo_Values(3)
            cmbRangeL.SelectedIndex = Last_Update_Combo_Values(4)
            cmbRangeH.SelectedIndex = Last_Update_Combo_Values(5)
            cmbScale.SelectedIndex = Last_Update_Combo_Values(6)
            cmbKey.SelectedIndex = Last_Update_Combo_Values(7)
            cmbInstrument.SelectedIndex = Last_Update_Combo_Values(8)
            numudTempo.Value = Last_Update_Combo_Values(9)


        End If
        ScaleAndKey()
        Filewrite(filepathA)
        Filewrite(filepathB)
        wmp1.URL = filepathB
        wmp1.settings.playCount = Last_Update_Combo_Values(0) + 1
        wmp1.Ctlcontrols.stop()
    End Sub



    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If Not Updating_Bool Then
            If wmp1.status = "Stopped" Or wmp1.status = "Ready" Then
                If wmp1.URL = filepathA Then
                    wmp1.URL = ""
                    wmp1.URL = filepathB
                Else
                    wmp1.URL = ""
                    wmp1.URL = filepathA
                End If
                wmp1.Ctlcontrols.play()
                If wmp1.URL = filepathA Then
                    Filewrite(filepathB)
                Else
                    Filewrite(filepathA)
                End If
            End If
        End If
        'wmp1.Saved_Settings.volume = 10
    End Sub

    Private Sub Filewrite(filepath As String)
        Dim File_Midi_Header() As Byte = {&H4D, &H54, &H68, &H64, &H0, &H0, &H0, &H6}
        Dim File_SubFormat_Type() As Byte = {&H0, &H0} ' Type-1 MIDI file (as opposed to Type-0)
        Dim File_Track_Number() As Byte = {&H0, &H1}
        Dim File_Speed() As Byte = {CByte(Last_Update_Combo_Values(10)), CByte(Last_Update_Combo_Values(11))}  ' Tempo (sort of)
        Dim File_Track_Header() As Byte = {&H4D, &H54, &H72, &H6B, &H0, &H0, &H0}
        Dim File_Temp_Byte_Count As Byte
        File_Temp_Byte_Count = CByte(((Last_Update_Combo_Values(1) + 1) * 7) + 12 + (Last_Update_Combo_Values(3) * 7))
        Dim File_Track_Byte_Count() As Byte = {File_Temp_Byte_Count} 'number of notes + 4 for silence and 4 for File_Track_End + 3 for instrument change + 1 for first &H0 of data section
        Dim File_Track_Note_Data(500) As Byte
        Dim File_Hold_Each_Note_Byte() As Byte = {&HFF}
        Dim File_Track_Pause_Data() As Byte = {&H0, &H3E, &H0, &H83, &H0, &H3E, &H0}
        Dim File_Track_Silence_All() As Byte = {&H7F, &HB0, &H7B, &H0}
        Dim File_Track_End() As Byte = {&H0, &HFF, &H2F, &H0}
        'Dim Instrument_Byte As Byte
        Dim File_Instrument() As Byte = {&H0, &HC0, CByte(Last_Update_Combo_Values(8))} '&H41}
        Dim x3 As Integer
        Dim Note_Count As Integer
        Dim Rest_Count As Integer = Last_Update_Combo_Values(3)
        Dim Note_Timing As Integer



        Note_Count = (Last_Update_Combo_Values(1) + 1)
        x3 = 0
        File_Track_Note_Data(0) = &H0
        Previous_Note = -1
        Do Until x3 = Note_Count
            If ((x3 * 7) + 1) = 1 Then
                File_Track_Note_Data((x3 * 7) + 1) = &H90
            Else
                File_Track_Note_Data((x3 * 7) + 1) = &H0
            End If
            File_Track_Note_Data((x3 * 7) + 2) = GetNote()
            File_Track_Note_Data((x3 * 7) + 3) = &H60

            If Last_Update_Combo_Values(2) = 4 Then
                Note_Timing = CSng(Int(Rnd() * 4))
            Else
                Note_Timing = Last_Update_Combo_Values(2)
            End If
            Select Case (Note_Timing)
                Case 0
                    File_Track_Note_Data((x3 * 7) + 4) = &H81
                Case 1
                    File_Track_Note_Data((x3 * 7) + 4) = &H82
                Case 2
                    File_Track_Note_Data((x3 * 7) + 4) = &H84
                Case 3
                    File_Track_Note_Data((x3 * 7) + 4) = &H88
            End Select

            File_Track_Note_Data((x3 * 7) + 5) = &H0
            File_Track_Note_Data((x3 * 7) + 6) = File_Track_Note_Data((x3 * 7) + 2)
            File_Track_Note_Data((x3 * 7) + 7) = &H0
            x3 = x3 + 1
        Loop

        If My.Computer.FileSystem.FileExists(filepath) Then
            My.Computer.FileSystem.DeleteFile(filepath)
        End If
        My.Computer.FileSystem.WriteAllBytes(filepath, File_Midi_Header, True)
        My.Computer.FileSystem.WriteAllBytes(filepath, File_SubFormat_Type, True)
        My.Computer.FileSystem.WriteAllBytes(filepath, File_Track_Number, True)
        My.Computer.FileSystem.WriteAllBytes(filepath, File_Speed, True)
        My.Computer.FileSystem.WriteAllBytes(filepath, File_Track_Header, True)
        My.Computer.FileSystem.WriteAllBytes(filepath, File_Track_Byte_Count, True)
        My.Computer.FileSystem.WriteAllBytes(filepath, File_Instrument, True)
        'My.Computer.FileSystem.WriteAllBytes(filepath, File_Track_Note_Data, True)
        For x3 = 0 To (Note_Count * 7)
            File_Hold_Each_Note_Byte(0) = File_Track_Note_Data(x3)
            My.Computer.FileSystem.WriteAllBytes(filepath, File_Hold_Each_Note_Byte, True)
        Next
        For x3 = 1 To Rest_Count
            My.Computer.FileSystem.WriteAllBytes(filepath, File_Track_Pause_Data, True)
        Next
        My.Computer.FileSystem.WriteAllBytes(filepath, File_Track_Silence_All, True)
        My.Computer.FileSystem.WriteAllBytes(filepath, File_Track_End, True)

    End Sub

    Private Sub ScaleAndKey()
        Dim x4 As Integer = 0
        Dim Scale_String As String
        Dim x6 As Integer
        x6 = Last_Update_Combo_Values(6)    '6 corresponds to cmbScale
        Scale_String = All_Scales_Data(x6)
        Array.Clear(Notes_Scale_And_Key, 0, Notes_Scale_And_Key(0))
        Notes_Scale_And_Key = Split(Scale_String, ",")
        For x4 = 1 To Notes_Scale_And_Key(0)
            Notes_Scale_And_Key(x4) = Int(Notes_Scale_And_Key(x4)) + Int(Last_Update_Combo_Values(7))  '7 corresponds to cmbKey
            If Notes_Scale_And_Key(x4) > 36 Then
                Notes_Scale_And_Key(x4) = Int(Notes_Scale_And_Key(x4)) - 36
            End If
            If Notes_Scale_And_Key(x4) = 36 And Last_Update_Combo_Values(7) <> 0 Then
                Notes_Scale_And_Key(0) = Int(Notes_Scale_And_Key(0)) + 1
            End If
        Next
    End Sub

    Private Function GetNote() As Byte

        Dim Next_Note_Byte As Byte
        Dim x5 As Integer = 0
        Dim New_Note_Integer As Integer
        Dim This_Note_Matches_Bool As Boolean = False
        Do While This_Note_Matches_Bool = False
            New_Note_Integer = CSng(Int(Rnd() * 37))
            For x5 = 1 To Int(Notes_Scale_And_Key(0))
                If New_Note_Integer = Notes_Scale_And_Key(x5) Then
                    This_Note_Matches_Bool = True
                End If
            Next
            If This_Note_Matches_Bool = True And Previous_Note <> -1 Then
                If New_Note_Integer = Previous_Note Then
                    This_Note_Matches_Bool = False
                End If
            End If
            If This_Note_Matches_Bool = True And Previous_Note <> -1 Then
                If (Previous_Note < (New_Note_Integer - 12) Or Previous_Note > (New_Note_Integer + 12)) Then
                    This_Note_Matches_Bool = False
                End If
            End If
            If This_Note_Matches_Bool = True And (New_Note_Integer < Last_Update_Combo_Values(4) Or New_Note_Integer > Last_Update_Combo_Values(5)) Then
                This_Note_Matches_Bool = False
            End If
        Loop
        Previous_Note = New_Note_Integer
        Next_Note_Byte = CByte(New_Note_Integer + 40)
        Return Next_Note_Byte

    End Function

    Private Sub btnPause_Click(sender As Object, e As EventArgs) Handles btnPause.Click
        If btnPause.Text = "Play" Then
            wmp1.Ctlcontrols.play()
            btnPause.Text = "Pause"
        Else
            wmp1.Ctlcontrols.pause()
            btnPause.Text = "Play"
        End If
    End Sub

    Private Sub frmEar1_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Dim Ctrl As System.Windows.Forms.Control
        For Each Ctrl In Me.Controls
            If TypeOf Ctrl Is ComboBox Or TypeOf Ctrl Is NumericUpDown Then
                Ctrl.Left = Me.Width / 2
                Ctrl.Top = 60 + (Ctrl.TabIndex * 35)
            End If
            If TypeOf Ctrl Is Label Then
                Ctrl.Width = 140
                Ctrl.Left = (Me.Width / 2) - 155
                Ctrl.Top = 60 + (Ctrl.TabIndex * 35)
            End If
            If TypeOf Ctrl Is Button Then
                Ctrl.Width = 135
                Ctrl.Left = (Me.Width / 2) - 150
            End If

        Next
    End Sub

    Private Sub Tempo_Bytes()
        Dim Beats_Per_Second As Integer
        Dim Midi_Ticks As Long
        Beats_Per_Second = numudTempo.Value
        Midi_Ticks = Beats_Per_Second * 8.533333
        Last_Update_Combo_Values(10) = (Int(Midi_Ticks / 256))
        Last_Update_Combo_Values(11) = (Int(Midi_Ticks) Mod 256)
        txtMisc.Text = Last_Update_Combo_Values(10)
        txtWmpStatus.Text = Last_Update_Combo_Values(11)

    End Sub

End Class